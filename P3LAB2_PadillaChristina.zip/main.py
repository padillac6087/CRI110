ser1 = 'Oil change'
ser2 = 'Tire rotation'
ser3 = 'Car wash'

type1 = 'oil change'
type2 = 'tire rotation'
type3 = 'car wash'

cost1 = 35
cost2 = 19
cost3 = 7

auto_service = input('Enter desired auto service:\n')

if auto_service in ser1:
    print('You entered: {}'.format(ser1))
    print('Cost of {}: ${}'.format(type1, cost1))
    
elif auto_service in ser2:
    print('You entered: {}'.format(ser2))
    print('Cost of {}: ${}'.format(type2, cost2))
    
elif auto_service in ser3:
    print('You entered: {}'.format(ser3))
    print('Cost of {}: ${}'.format(type3, cost3))
    
else:
    print('You entered: {}'.format(auto_service))
    print('Error: Requested service is not recognized')